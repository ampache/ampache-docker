import{h as t,m as r}from"./vendor-aj9xRtWY.js";var s=t("<h1>Podcast episode</h1>");function e(o){var a=s();r(o,a)}export{e as default};
