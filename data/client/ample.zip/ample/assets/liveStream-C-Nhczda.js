import{h as t,m as r}from"./vendor-aj9xRtWY.js";var m=t("<h1>Radio station</h1>");function h(a){var o=m();r(a,o)}export{h as default};
